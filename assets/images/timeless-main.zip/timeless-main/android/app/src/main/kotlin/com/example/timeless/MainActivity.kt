package com.example.timeless

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
