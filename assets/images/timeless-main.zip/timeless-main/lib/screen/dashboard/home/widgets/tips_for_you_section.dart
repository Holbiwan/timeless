import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:timeless/utils/app_style.dart';
import 'package:timeless/utils/asset_res.dart';
import 'package:timeless/utils/color_res.dart';
import 'package:timeless/utils/string.dart';

Widget tipsForYouSection() {
  return Column(
    children: [
      const SizedBox(height: 27),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18),
        child: Row(
          children: [
            Text(
              Strings.tipsForYou,
              style: appTextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 16,
                color: ColorRes.textPrimary,
              ),
            ),
            const Spacer(),
            // Text(Strings.seeAll,
            //     style: appTextStyle(
            //         fontSize: 14,
            //         fontWeight: FontWeight.w500,
            //         color: ColorRes.containerColor))

            // Text("See all",style: GoogleFonts.poppins(fontSize: ),)
          ],
        ),
      ),
      const SizedBox(height: 18),
      Container(
        margin: const EdgeInsets.symmetric(horizontal: 18),
        height: 150,
        decoration: BoxDecoration(
          borderRadius: const BorderRadius.all(Radius.circular(15)),
          gradient: const LinearGradient(colors: [
            Colors.black87,
            Colors.black,
          ]),
          boxShadow: [
            BoxShadow(
                offset: const Offset(6, 6),
                color: Colors.grey.withOpacity(0.3),
                spreadRadius: 0,
                blurRadius: 10),
            BoxShadow(
                offset: const Offset(0, 7),
                color: Colors.grey.withOpacity(0.2),
                spreadRadius: 0,
                blurRadius: 20),
          ],
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.only(left: 20),
              width: Get.width - 160,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                // ignore: prefer_const_literals_to_create_immutables
                children: [
                  Text(
                    Strings.howToFindAPerfectJob,
                    style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w500,
                        fontSize: 18,
                        color: ColorRes.white),
                  ),
                  SizedBox(
                    child: Container(
                      height: 32,
                      width: 110,
                      margin: const EdgeInsets.only(top: 15),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      alignment: Alignment.center,
                      decoration: const BoxDecoration(
                          color: ColorRes.orange,
                          borderRadius: BorderRadius.all(Radius.circular(10))),
                      child: Text(
                        Strings.readMore,
                        style: appTextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 12,
                          color: ColorRes.white,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            const Spacer(),
            Image.asset(AssetRes.girlImage),
            const SizedBox(width: 20)
          ],
        ),
      ),
      const SizedBox(height: 27),
    ],
  );
}
