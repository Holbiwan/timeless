import 'package:get/get.dart';

class JobDetailsController extends GetxController {
  RxList requirements = [
    "Experienced in Figma or Sketch.",
    "Able to work in large or small team.",
    "At least 1 year of working experience in agency freelance, or start-up.",
    "Able to keep up with the latest trends.",
    "Have relevant experience for at least 3 years."
  ].obs;
}
