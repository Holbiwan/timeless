import 'package:get/get.dart';

class JobDetailsController extends GetxController{
  var args = Get.arguments;

}