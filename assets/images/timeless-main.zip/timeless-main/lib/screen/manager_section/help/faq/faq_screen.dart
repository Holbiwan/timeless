import 'package:flutter/material.dart';
import 'package:timeless/utils/color_res.dart';

class FaqScreen extends StatelessWidget {
  const FaqScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: ColorRes.backgroundColor,
      body: Column(
        children: [

          // Text('FAQ'),
        ],
      ),
    );
  }
}
