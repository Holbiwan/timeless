class AppRes {
  static String notificationScreen = "/notificationScreen";
  static String jobDetailScreen = "/jobDetailScreen";
  static String jobDetailUploadCvScreen = "/jobDetailUploadCvScreen";
  static String jobDetailSuccessOrFailed = "/jobDetailSuccessOrFailed";
  static String jobRecommendationScreen = "/jobRecommendationScreen";
  static String organizationProfileScreen = "/organizationProfileScreen";
  static String managerDashboardScreen = "/managerDashboardScreen";
  static String managerApplicationDetailScreen = "/managerApplicationDetailScreen";
  static String resumeScreen = "/resumeScreen";
  static String applicantsDetails = "/applicantsDetails";
  static String seeDetailsScreen = "/seeDetailsScreen";
  static String applicationsUser = "/applicationsUser";
  static String firstScreen = "/FirstScreen";
  static String lookingForScreen = "/LookingForScreen";
  static String updateVacanciesRequirementScreen = "/UpdateVacanciesRequirementScreen";
  static String firstPageScreenM = "/FirstPageScreenM";
  static String newHomePageUi = "/NewHomePageUi";
}
