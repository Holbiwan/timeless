class FontRes {
  static const interRegular = "inter-regular";
  static const interBold = "inter-bold";
}