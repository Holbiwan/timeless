// lib/screen/profile/profile_controller.dart
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:timeless/service/pref_services.dart';
import 'package:timeless/utils/pref_keys.dart';

class ProfileUserController extends GetxController implements GetxService {
  final TextEditingController fullNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController occupationController = TextEditingController();
  final TextEditingController dateOfBirthController = TextEditingController();

  final RxBool isNameValidate = false.obs;
  final RxBool isEmailValidate = false.obs;
  final RxBool isAddressValidate = false.obs;
  final RxBool isOccupationValidate = false.obs;
  final RxBool isbirthValidate = false.obs;

  DateTime? startTime;
  final ImagePicker picker = ImagePicker();
  File? image;
  final RxBool isLod = false.obs;
  String url = "";
  final RxString fbImageUrl = "".obs;

  static FirebaseFirestore fireStore = FirebaseFirestore.instance;

  void onChanged(String value) => update(["colorChange"]);

  @override
  void onInit() {
    fullNameController.text = PrefService.getString(PrefKeys.fullName);
    emailController.text = PrefService.getString(PrefKeys.email);
    occupationController.text = PrefService.getString(PrefKeys.occupation);
    dateOfBirthController.text = PrefService.getString(PrefKeys.dateOfBirth);
    addressController.text = PrefService.getString(PrefKeys.address);

    final imgPath = PrefService.getString(PrefKeys.imageId);
    if (imgPath.isNotEmpty) {
      image = File(imgPath);
    }
    getFbImgUrl();
    super.onInit();
  }

  Future<void> getFbImgUrl() async {
    fbImageUrl.value = PrefService.getString(PrefKeys.imageId);
    if (kDebugMode) {
      print("fbIMGURL $fbImageUrl");
    }
  }

  Future<void> onDatePickerTap(BuildContext context) async {
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      initialEntryMode: DatePickerEntryMode.calendarOnly,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: ThemeData(primarySwatch: Colors.blue),
          child: child!,
        );
      },
    );
    startTime = picked;
    if (kDebugMode) {
      print("START TIME : $startTime");
    }

    if (picked != null) {
      dateOfBirthController.text =
          "${picked.toLocal().month}/${picked.toLocal().day}/${picked.toLocal().year}";
      update();
    }
  }

  // ======= MÉTHODES MANQUANTES =======

  /// Ouvre la caméra puis enregistre localement le chemin de l’image sélectionnée
  Future<void> onTap() async {
    try {
      final XFile? file =
          await picker.pickImage(source: ImageSource.camera, imageQuality: 80);
      if (file == null) return;
      image = File(file.path);
      await PrefService.setValue(PrefKeys.imageId, image!.path);
      await getFbImgUrl();
      update();
    } catch (e) {
      if (kDebugMode) print(e);
      Get.snackbar("Camera", "Failed to capture image",
          colorText: const Color(0xffDA1414));
    }
  }

  /// Ouvre la galerie puis enregistre localement le chemin de l’image sélectionnée
  Future<void> onTapGallery() async {
    try {
      final XFile? file =
          await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
      if (file == null) return;
      image = File(file.path);
      await PrefService.setValue(PrefKeys.imageId, image!.path);
      await getFbImgUrl();
      update();
    } catch (e) {
      if (kDebugMode) print(e);
      Get.snackbar("Gallery", "Failed to pick image",
          colorText: const Color(0xffDA1414));
    }
  }

  /// Sauvegarde des infos de profil dans Firestore (sans upload storage)
  Future<void> editTap() async {
    final userId = PrefService.getString(PrefKeys.userId);
    if (userId.isEmpty) {
      Get.snackbar("Profile", "User not logged in",
          colorText: const Color(0xffDA1414));
      return;
    }
    isLod.value = true;
    try {
      await fireStore
          .collection("Auth")
          .doc("User")
          .collection("register")
          .doc(userId)
          .set({
        "fullName": fullNameController.text.trim(),
        "Email": emailController.text.trim(),
        "address": addressController.text.trim(),
        "Occupation": occupationController.text.trim(),
        "dateOfBirth": dateOfBirthController.text.trim(),
        "updatedAt": FieldValue.serverTimestamp(),
        "imageLocalPath":
            image?.path ?? PrefService.getString(PrefKeys.imageId),
      }, SetOptions(merge: true));

      // MàJ Prefs locales
      PrefService.setValue(PrefKeys.fullName, fullNameController.text.trim());
      PrefService.setValue(PrefKeys.email, emailController.text.trim());
      PrefService.setValue(PrefKeys.address, addressController.text.trim());
      PrefService.setValue(
          PrefKeys.occupation, occupationController.text.trim());
      PrefService.setValue(
          PrefKeys.dateOfBirth, dateOfBirthController.text.trim());
      if (image != null) {
        PrefService.setValue(PrefKeys.imageId, image!.path);
      }

      Get.snackbar("Profile", "Profile updated");
      update();
    } catch (e) {
      if (kDebugMode) print(e);
      Get.snackbar("Profile", "Update failed",
          colorText: const Color(0xffDA1414));
    } finally {
      isLod.value = false;
    }
  }
}
